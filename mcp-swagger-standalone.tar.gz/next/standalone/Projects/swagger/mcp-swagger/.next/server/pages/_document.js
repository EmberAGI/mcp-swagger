var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__3719d367._.js")
R.c("server/chunks/ssr/[root-of-the-server]__1f561d98._.js")
R.m(28589)
module.exports=R.m(28589).exports
