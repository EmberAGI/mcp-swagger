var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/test-url/route.js")
R.c("server/chunks/[root-of-the-server]__b2465d88._.js")
R.c("server/chunks/f94c4_next_8b7ed1f1._.js")
R.m(4355)
R.m(12528)
module.exports=R.m(12528).exports
