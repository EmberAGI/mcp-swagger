var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/mcp-proxy/route.js")
R.c("server/chunks/[root-of-the-server]__5d6f202b._.js")
R.c("server/chunks/f94c4_next_8b7ed1f1._.js")
R.c("server/chunks/[root-of-the-server]__2d71f439._.js")
R.m(24691)
R.m(3378)
module.exports=R.m(3378).exports
