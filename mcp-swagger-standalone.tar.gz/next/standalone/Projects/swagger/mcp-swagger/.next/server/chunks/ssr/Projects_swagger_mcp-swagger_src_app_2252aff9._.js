module.exports=[60620,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},79166,a=>{"use strict";a.s(["default",()=>b]);let b={src:a.i(60620).default,width:256,height:256}}];

//# sourceMappingURL=Projects_swagger_mcp-swagger_src_app_2252aff9._.js.map