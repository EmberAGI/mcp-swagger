globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/ff5c9d84343e2a5d.js",
      "static/chunks/600bbf4afcd14267.js",
      "static/chunks/turbopack-3d459843fb2b21bf.js"
    ],
    "/_error": [
      "static/chunks/210e6b167a3d16c3.js",
      "static/chunks/600bbf4afcd14267.js",
      "static/chunks/turbopack-bd6920690adf5c0b.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/271aef4c876c6dd6.js",
    "static/chunks/b75df4aa7040e724.js",
    "static/chunks/0ee2c727da243530.js",
    "static/chunks/2453a0dcf0b3fd5d.js",
    "static/chunks/turbopack-477528b32d5b8876.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];