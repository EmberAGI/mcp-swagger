var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_error.js")
R.c("server/chunks/ssr/[root-of-the-server]__3719d367._.js")
R.c("server/chunks/ssr/[root-of-the-server]__1f561d98._.js")
R.c("server/chunks/ssr/f94c4_next_74eea8f4._.js")
R.c("server/chunks/ssr/[externals]_next_dist_shared_lib_no-fallback-error_external_59b92b38.js")
R.c("server/chunks/ssr/f94c4_05adc525._.js")
R.m(18955)
module.exports=R.m(18955).exports
