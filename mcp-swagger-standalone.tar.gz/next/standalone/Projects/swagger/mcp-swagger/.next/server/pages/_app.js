var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__e3ffb027._.js")
R.m(65214)
module.exports=R.m(65214).exports
