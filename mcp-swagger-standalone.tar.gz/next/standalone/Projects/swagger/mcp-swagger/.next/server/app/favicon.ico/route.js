var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__8b6b2c7f._.js")
R.c("server/chunks/f94c4_next_dist_2be175f8._.js")
R.c("server/chunks/f94c4_next_dist_32201895._.js")
R.c("server/chunks/f94c4_next_9804d040._.js")
R.m(22170)
R.m(76200)
module.exports=R.m(76200).exports
